const trending = [
  ["Anime", "The ultimate anime watchlist for new fans", "12 min read"],
  ["Gaming", "10 games to add to your weekend rotation", "8 min read"],
  ["Quiz", "Can you identify the anime character?", "5 min quiz"]
];
const anime = [
  ["ACTION", "Build your dream anime squad", "Rank characters, teams and legendary moments."],
  ["RANKINGS", "Anime power rankings", "Create your own fan ranking and compare it with others."],
  ["COMMUNITY", "What should you watch next?", "Vote in community polls and discover something new."]
];

function card(data, imageClass=""){
  return `<article class="card"><div class="card-img ${imageClass}"><span>${data[0]}</span></div><div class="card-body"><h3>${data[1]}</h3><p>${data[2]}</p><div class="meta">OTAKUVERSE • JUST NOW</div></div></article>`;
}
document.getElementById("trendingCards").innerHTML = trending.map(x=>card(x)).join("");
document.getElementById("animeCards").innerHTML = anime.map(x=>card(x)).join("");

const answers = document.querySelectorAll(".answers button");
const result = document.getElementById("quizResult");
const quizResults = {
 hero:"You are the Hero — determined, loyal and always ready for the next adventure! ⚡",
 strategist:"You are the Strategist — observant, clever and three steps ahead. 🧠",
 rival:"You are the Rival — ambitious, competitive and always improving. 🔥",
 comic:"You are the Comic Relief — you keep the squad laughing through every arc. 😎"
};
answers.forEach(btn => btn.addEventListener("click",()=>{
 result.textContent = quizResults[btn.dataset.type];
 answers.forEach(b=>b.disabled=true);
}));

const modal=document.getElementById("searchModal");
document.getElementById("searchBtn").onclick=()=>modal.classList.add("show");
document.getElementById("closeSearch").onclick=()=>modal.classList.remove("show");
document.getElementById("searchInput").addEventListener("input", e=>{
 const q=e.target.value.toLowerCase();
 const items=[...trending,...anime].filter(x=>x.join(" ").toLowerCase().includes(q));
 document.getElementById("searchResults").innerHTML=q
  ? (items.length?items.map(x=>`<div class="result"><strong>${x[1]}</strong><br><small>${x[0]}</small></div>`).join(""):"<div class='result'>No results found.</div>")
  : "";
});

document.getElementById("newsletterForm").addEventListener("submit",e=>{
 e.preventDefault();
 const email=document.getElementById("email").value;
 showToast(`Thanks! ${email} is on the list.`);
 e.target.reset();
});
function showToast(message){
 const t=document.getElementById("toast"); t.textContent=message;t.classList.add("show");
 setTimeout(()=>t.classList.remove("show"),2800);
}
