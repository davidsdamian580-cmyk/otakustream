# OtakuVerse

A responsive anime + gaming entertainment website starter.

## Run it
Open `index.html` in a browser.

## Before launching publicly
- Replace placeholder content with your own/original or properly licensed content.
- Connect the newsletter form to a real email service.
- Add a backend/CMS if you want users, comments, accounts, or regularly updated articles.
- Add a compliant ad network once you have traffic and meet its requirements.
- Add affiliate disclosures for affiliate links.
